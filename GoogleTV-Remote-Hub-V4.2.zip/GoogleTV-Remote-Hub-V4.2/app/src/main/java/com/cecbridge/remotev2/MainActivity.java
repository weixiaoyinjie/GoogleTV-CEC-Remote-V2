package com.cecbridge.remotev2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Phone-only remote controller for Google TV via Remote v2; no CEC code. */
public final class MainActivity extends Activity {
    private static final int BG=0xff08090b, PANEL=0xff181b20, LIGHT=0xfff5f7fa,
            SUB=0xffaab2bd, ACCENT=0xff62d0c0, GREEN=0xff176657, RED=0xff713744;
    private static final String PREFS="google_tv_remote_v2"; // keep V3 pairing data
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final List<SavedApp> savedApps=new ArrayList<>();
    private SharedPreferences prefs;
    private EditText hostField, pinField;
    private TextView statusView, powerView;
    private LinearLayout appsGrid;
    private Button launchModeButton;
    private IdentityStore identity;
    private PairingClient pairing;
    private RemoteSession remote;
    private NsdManager nsd;
    private NsdManager.DiscoveryListener discovery;
    private volatile boolean resolving;

    private static final class SavedApp {
        String name, target;
        SavedApp(String n,String t){name=n;target=t;}
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        restoreApps();
        disableLegacyShortcuts();
        buildUi();
        io.execute(() -> {
            try {
                identity=new IdentityStore(getApplicationContext());
                remote=createRemote();
                String host=prefs.getString("host", "");
                if(!host.isEmpty()&&!prefs.getString("tv_fingerprint", "").isEmpty())
                    connectInternal(host);
                else showStatus("首次使用：输入电视 IP，点击首次配对，并填写电视上的六位配对码",false);
            } catch(Exception e) { showStatus("初始化失败："+e.getMessage(),true); }
        });
    }

    private RemoteSession createRemote(){
        return new RemoteSession(identity,new RemoteSession.Listener(){
            @Override public void status(String s){showStatus(s,false);}
            @Override public void powerState(Boolean on){
                runOnUiThread(() -> {
                    if(powerView!=null)powerView.setText(on==null?"Google TV · 状态未知":
                            on?"Google TV · 正在运行":"Google TV · 待机");
                });
            }
        });
    }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(19),dp(22),dp(19),dp(38));
        scroll.addView(root);
        setContentView(scroll);

        TextView title=label("TV REMOTE",28,LIGHT,true);
        title.setLetterSpacing(.075f);
        root.addView(title);
        root.addView(label("Google TV · 手机端 · 局域网",12,SUB,false));
        gap(root,19);

        root.addView(label("Google TV 电源",18,LIGHT,true));
        powerView=label("Google TV · 尚未连接",13,ACCENT,false);
        root.addView(powerView);
        gap(root,8);
        Button power=button(root,"⏻",GREEN,0,()->key(26,"电源切换"));
        power.setTextSize(34);
        power.setContentDescription("切换 Google TV 电源");
        LinearLayout.LayoutParams powerLayout=(LinearLayout.LayoutParams)power.getLayoutParams();
        powerLayout.height=dp(70);power.setLayoutParams(powerLayout);
        gap(root,8);
        button(root,"＋ 添加桌面电源图标",PANEL,0,()->pinPowerShortcut(
                QuickActionActivity.ACTION_TOGGLE,"tv-toggle","Google TV 开关",R.drawable.ic_shortcut_toggle));
        root.addView(label("手机桌面图标一键发送同样的电源切换指令，不打开完整遥控页面。",11,SUB,false));
        gap(root,11);
        statusView=label("正在初始化遥控器…",12,ACCENT,false);
        statusView.setPadding(dp(12),dp(12),dp(12),dp(12));
        statusView.setBackground(bg(PANEL));root.addView(statusView);
        gap(root,21);

        root.addView(label("Google Play 启动电视 App",18,LIGHT,true));
        root.addView(label("点击应用按钮从电视上的 Google Play 尝试启动；长按可编辑或删除。",12,SUB,false));
        gap(root,9);
        appsGrid=new LinearLayout(this);
        appsGrid.setOrientation(LinearLayout.VERTICAL);
        root.addView(appsGrid);
        renderApps();
        gap(root,5);
        button(root,"＋ 添加其他电视 App",PANEL,0,()->editApp(-1));
        gap(root,10);
        launchModeButton=button(root,"",PANEL,0,this::cyclePlayMode);
        refreshPlayModeText();
        root.addView(label("自动确认模式会在打开商店详情页后发送一次“确定”。请先用手动模式确认焦点默认落在“打开”，否则可能误点安装或其他按钮。不同电视不保证自动启动。",11,SUB,false));
        gap(root,8);
        button(root,"手动确定 / 打开",PANEL,0,()->key(23,"电视确定键"));
        gap(root,20);

        LinearLayout media=foldSection(root,"媒体控制面板","media");
        media.addView(label("适用于支持系统媒体按键的播放器；实际效果取决于电视 App。",12,SUB,false));
        gap(media,9);
        LinearLayout transport=row(media);
        button(transport,"⏮ 上一个",PANEL,1,()->key(88,"上一个"));
        button(transport,"▶ / ❚❚",GREEN,1,()->key(85,"播放/暂停"));
        button(transport,"下一个 ⏭",PANEL,1,()->key(87,"下一个"));
        gap(media,8);
        LinearLayout ff=row(media);
        button(ff,"⏪ 快退",PANEL,1,()->key(89,"快退"));
        button(ff,"⏩ 快进",PANEL,1,()->key(90,"快进"));
        gap(media,8);
        LinearLayout alt=row(media);
        button(alt,"◀ 左方向/回退",PANEL,1,()->key(21,"左方向"));
        button(alt,"右方向/前进 ▶",PANEL,1,()->key(22,"右方向"));
        gap(media,8);
        button(media,"■ 停止播放",PANEL,0,()->key(86,"停止播放"));
        media.addView(label("方向键不保证精确快进；具体由 Kodi、Vimu 等播放器决定。",11,SUB,false));
        gap(root,10);

        LinearLayout directions=foldSection(root,"电视方向遥控","directions");
        gap(directions,9);
        LinearLayout up=row(directions);
        spacerButton(up);button(up,"▲",PANEL,1,()->key(19,"向上"));spacerButton(up);
        gap(directions,6);
        LinearLayout center=row(directions);
        button(center,"◀",PANEL,1,()->key(21,"向左"));
        button(center,"确定",GREEN,1,()->key(23,"确定"));
        button(center,"▶",PANEL,1,()->key(22,"向右"));
        gap(directions,6);
        LinearLayout down=row(directions);
        spacerButton(down);button(down,"▼",PANEL,1,()->key(20,"向下"));spacerButton(down);
        gap(directions,8);
        LinearLayout nav=row(directions);
        button(nav,"返回",PANEL,1,()->key(4,"返回"));
        button(nav,"主页",PANEL,1,()->key(3,"主页"));
        button(nav,"菜单",PANEL,1,()->key(82,"菜单"));
        gap(root,10);

        LinearLayout connectArea=foldSection(root,"连接与首次配对","pairing");
        connectArea.addView(label("手机和 Google TV 在同一局域网，配对证书保存在手机本地。",12,SUB,false));
        gap(connectArea,9);
        hostField=input("Google TV IP，例如 192.168.0.52",prefs.getString("host",""),
                InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        connectArea.addView(hostField);
        gap(connectArea,9);
        LinearLayout con=row(connectArea);
        button(con,"搜索电视",PANEL,1,this::startDiscovery);
        button(con,"连接电视",GREEN,1,this::connect);
        gap(connectArea,9);
        button(connectArea,"首次配对（电视显示六位代码）",PANEL,0,this::startPair);
        gap(connectArea,9);
        pinField=input("输入电视显示的六位配对码","",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        connectArea.addView(pinField);
        gap(connectArea,9);
        button(connectArea,"确认配对码并连接",GREEN,0,this::finishPair);
        gap(connectArea,9);
        button(connectArea,"忘记此电视的配对",PANEL,0,this::forgetPair);
        gap(root,12);
        root.addView(label("本 App 不控制 HDMI-CEC。应用打开与媒体按键属于发送遥控请求，需以电视实际响应为准。",11,SUB,false));
    }

    private LinearLayout foldSection(LinearLayout parent,String name,String id){
        final String key="fold_v42_"+id;
        boolean expanded=prefs.getBoolean(key,false);
        TextView heading=label((expanded?"▾  ":"▸  ")+name,18,LIGHT,true);
        heading.setPadding(dp(13),dp(17),dp(13),dp(17));
        heading.setBackground(bg(PANEL));
        heading.setContentDescription(name+"，点击展开或收起");
        parent.addView(heading,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(1),dp(10),dp(1),dp(5));
        parent.addView(content);
        content.setVisibility(expanded?View.VISIBLE:View.GONE);
        heading.setOnClickListener(v->{
            boolean open=content.getVisibility()!=View.VISIBLE;
            content.setVisibility(open?View.VISIBLE:View.GONE);
            heading.setText((open?"▾  ":"▸  ")+name);
            prefs.edit().putBoolean(key,open).apply();
        });
        return content;
    }

    /** Legacy launcher pins remain owned by the user; mark old wake/sleep pins disabled. */
    private void disableLegacyShortcuts(){
        try{
            ShortcutManager shortcuts=getSystemService(ShortcutManager.class);
            if(shortcuts!=null)shortcuts.disableShortcuts(
                    java.util.Arrays.asList("tv-wake","tv-sleep"),"旧版快捷方式已停用，请在桌面删除");
        }catch(Exception ignored){}
    }

    private int playMode(){return prefs.getInt("play_mode_v42",2);}
    private void cyclePlayMode(){
        int next=playMode()==2?1:playMode()==1?0:2;
        prefs.edit().putInt("play_mode_v42",next).apply();
        refreshPlayModeText();
    }
    private void refreshPlayModeText(){
        if(launchModeButton==null)return;
        int mode=playMode();
        String text=mode==0?"启动方式：Play 直启尝试":
                mode==1?"启动方式：详情页 + 自动按确定":"启动方式：详情页 + 手动确认";
        launchModeButton.setText(text+"  ↻");
    }

    private void restoreApps(){
        String saved=prefs.getString("custom_tv_apps_v4",null);
        if(saved==null){
            savedApps.add(new SavedApp("Kodi","org.xbmc.kodi"));
            savedApps.add(new SavedApp("Qobuz","com.qobuz.music"));
            return;
        }
        try{
            JSONArray array=new JSONArray(saved);
            for(int i=0;i<array.length();i++){
                JSONObject obj=array.getJSONObject(i);
                String name=obj.optString("name","").trim();
                String target=obj.optString("target","").trim();
                if(!name.isEmpty()&&!target.isEmpty())savedApps.add(new SavedApp(name,target));
            }
        }catch(Exception ignored){
            savedApps.clear();
            savedApps.add(new SavedApp("Kodi","org.xbmc.kodi"));
            savedApps.add(new SavedApp("Qobuz","com.qobuz.music"));
        }
    }
    private void persistApps(){
        JSONArray json=new JSONArray();
        for(SavedApp a:savedApps){
            JSONObject o=new JSONObject();
            try{o.put("name",a.name);o.put("target",a.target);}catch(Exception ignored){}
            json.put(o);
        }
        prefs.edit().putString("custom_tv_apps_v4",json.toString()).apply();
    }
    private void renderApps(){
        if(appsGrid==null)return;
        appsGrid.removeAllViews();
        for(int i=0;i<savedApps.size();i+=2){
            LinearLayout r=row(appsGrid);
            for(int j=i;j<Math.min(i+2,savedApps.size());j++){
                final int at=j;
                SavedApp item=savedApps.get(j);
                Button btn=button(r,item.name,at<2?GREEN:PANEL,1,()->launchViaPlay(item));
                btn.setOnLongClickListener(v->{editApp(at);return true;});
            }
            if(i+1>=savedApps.size())spacerButton(r);
            gap(appsGrid,9);
        }
        if(savedApps.isEmpty())appsGrid.addView(label("还没有快捷 App，点击下方添加。",12,SUB,false));
    }
    private void editApp(int index){
        boolean editing=index>=0&&index<savedApps.size();
        SavedApp old=editing?savedApps.get(index):new SavedApp("","");
        LinearLayout fields=new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(dp(18),dp(14),dp(18),0);
        EditText name=input("显示名称，例如 MX Player",old.name,InputType.TYPE_CLASS_TEXT);
        fields.addView(name);
        gap(fields,9);
        EditText target=input("电视 App 的 Android 包名",old.target,InputType.TYPE_CLASS_TEXT);
        fields.addView(target);
        TextView hint=label("只需包名，例如 Kodi：org.xbmc.kodi；Qobuz：com.qobuz.music。",12,SUB,false);
        gap(fields,8);fields.addView(hint);
        AlertDialog.Builder builder=new AlertDialog.Builder(this).setTitle(editing?"修改电视 App 快捷方式":"添加电视 App")
                .setView(fields).setNegativeButton("取消",null)
                .setPositiveButton("保存",null);
        if(editing)builder.setNeutralButton("删除",(d,w)->{
            savedApps.remove(index);persistApps();renderApps();
        });
        AlertDialog dialog=builder.create();dialog.setOnShowListener(v->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2->{
                    String n=name.getText().toString().trim();
                    String t=target.getText().toString().trim();
                    if(n.isEmpty()||n.length()>32||!validTarget(t)){
                        Toast.makeText(this,"请填写名称和有效的电视 App 包名",Toast.LENGTH_LONG).show();return;
                    }
                    if(editing){savedApps.get(index).name=n;savedApps.get(index).target=t;}
                    else savedApps.add(new SavedApp(n,t));
                    persistApps();renderApps();dialog.dismiss();
                }));
        dialog.show();
    }

    private void pinPowerShortcut(String action,String id,String shortLabel,int iconId){
        String host=saveHost();if(host==null)return;
        if(prefs.getString("tv_fingerprint","").isEmpty()){
            showStatus("请先完成 Google TV 六位代码配对，再添加桌面快捷方式。",true);return;
        }
        ShortcutManager manager=getSystemService(ShortcutManager.class);
        if(manager==null||!manager.isRequestPinShortcutSupported()){
            showStatus("当前手机桌面不支持自动添加固定快捷方式，可尝试长按 App 图标查看快捷功能。",true);return;
        }
        Intent intent=new Intent(this,QuickActionActivity.class);
        intent.setAction(action);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        ShortcutInfo shortcut=new ShortcutInfo.Builder(this,id)
                .setShortLabel(shortLabel)
                .setLongLabel(shortLabel+"（Wi-Fi 遥控）")
                .setIcon(Icon.createWithResource(this,iconId))
                .setIntent(intent).build();
        try {
            if(manager.requestPinShortcut(shortcut,null))
                showStatus("请在 Android 弹出的确认窗口里添加「"+shortLabel+"」到桌面。",false);
            else showStatus("未能请求添加快捷方式，请检查当前桌面启动器。",true);
        } catch(Exception e){showStatus("无法添加桌面快捷方式："+e.getMessage(),true);}
    }

    private static boolean validTarget(String raw){
        return raw!=null && raw.length()<=150 &&
                raw.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+");
    }

    /** One tap launches via Google Play. Modes are explicitly chosen by user.
     *  In auto mode a delayed DPAD_CENTER may activate the wrong Play control.
     */
    private void launchViaPlay(SavedApp app){
        if(!validTarget(app.target)){
            showStatus("「"+app.name+"」不是有效包名。请长按修改成 Android 包名。",true);return;
        }
        String host=saveHost();if(host==null)return;
        final int mode=playMode();
        io.execute(()->{
            try{
                ensureConnected(host);
                if(mode==0){
                    remote.launchApp(app.target);
                    showStatus("已尝试通过 Google Play 一键启动「"+app.name+"」。若只出现商店，请切换到自动确认模式。",false);
                }else{
                    remote.openAppStorePage(app.target);
                    if(mode==1){
                        // Give the TV Play Store time to show the details screen.
                        // No foreground/focus telemetry: this is opt-in only.
                        Thread.sleep(1900);
                        remote.sendKey(23);
                        showStatus("已发送「"+app.name+"」Play 详情页与自动确定指令。请检查电视是否真正打开 App。",false);
                    }else{
                        showStatus("已请求打开电视 Google Play 的「"+app.name+"」详情页，可按下方“手动确定 / 打开”。",false);
                    }
                }
            }catch(InterruptedException e){
                Thread.currentThread().interrupt();showStatus("启动操作已中断",true);
            }catch(Exception e){showStatus("Google Play 启动请求失败："+e.getMessage(),true);}
        });
    }

    private void key(int code,String name){
        String host=saveHost();if(host==null)return;
        io.execute(()->{
            try{
                ensureConnected(host);
                remote.sendKey(code);
                showStatus("已发送「"+name+"」。具体响应由电视和当前播放器决定。",false);
            }catch(Exception e){showStatus("发送「"+name+"」失败："+e.getMessage(),true);}
        });
    }
    private String saveHost(){
        String host=hostField.getText().toString().trim();
        if(host.isEmpty()||host.contains("://")||host.contains("/")||host.contains(" ")||host.contains(":")){
            showStatus("请输入 Google TV 的有效 IPv4 地址或主机名",true);return null;
        }
        prefs.edit().putString("host",host).apply();return host;
    }
    private void ensureConnected(String host)throws Exception{
        if(remote==null||identity==null)throw new IllegalStateException("遥控器尚未初始化");
        if(!remote.isReady()){
            String fp=prefs.getString("tv_fingerprint","");
            if(fp.isEmpty())throw new IllegalStateException("请先完成六位码配对");
            remote.connect(host,fp);
        }
    }
    private void connect(){String host=saveHost();if(host!=null)io.execute(()->connectInternal(host));}
    private void connectInternal(String host){
        if(identity==null){showStatus("证书尚未初始化",true);return;}
        try{
            String fp=prefs.getString("tv_fingerprint","");
            if(fp.isEmpty())throw new IllegalStateException("未配对，请先输入电视显示的六位代码");
            showStatus("正在连接 Google TV："+host,false);
            remote.connect(host,fp);
            showStatus("已连接 Google TV，可以操作本机电源、启动 App 和媒体控制。",false);
        }catch(Exception e){showStatus("连接失败："+e.getMessage(),true);}
    }
    private void startPair(){
        String host=saveHost();if(host==null)return;
        io.execute(()->{
            try{
                if(identity==null)throw new IllegalStateException("证书尚未初始化");
                if(pairing!=null)pairing.close();
                if(remote!=null)remote.close();
                pairing=new PairingClient(identity);
                showStatus("请求电视显示六位配对码…",false);
                pairing.begin(host);
                showStatus("请将 Google TV 上显示的六位代码填入下方。",false);
            }catch(Exception e){showStatus("开始配对失败："+e.getMessage(),true);}
        });
    }
    private void finishPair(){
        String pin=pinField.getText().toString().trim();
        String host=saveHost();if(host==null)return;
        if(!pin.matches("(?i)[0-9a-f]{6}")){showStatus("请输入 6 位配对码（0–9 或 A–F）",true);return;}
        io.execute(()->{
            try{
                if(pairing==null)throw new IllegalStateException("请先点击首次配对");
                String fp=pairing.finish(pin);
                prefs.edit().putString("tv_fingerprint",fp).apply();
                runOnUiThread(()->pinField.setText(""));
                showStatus("配对成功，正在连接…",false);
                connectInternal(host);
            }catch(Exception e){showStatus("配对失败："+e.getMessage()+"，可以重新开始配对。",true);}
        });
    }
    private void forgetPair(){
        io.execute(()->{
            if(pairing!=null)pairing.close();
            if(remote!=null)remote.close();
            prefs.edit().remove("tv_fingerprint").apply();
            showStatus("本机配对记录已清除；再次连接需重新输入配对码。",false);
        });
    }
    private void startDiscovery(){
        try{
            if(discovery!=null){showStatus("正在搜索电视…",false);return;}
            nsd=(NsdManager)getSystemService(Context.NSD_SERVICE);
            discovery=new NsdManager.DiscoveryListener(){
                @Override public void onDiscoveryStarted(String type){showStatus("局域网搜索中…",false);}
                @Override public void onServiceFound(NsdServiceInfo service){
                    if(resolving)return;
                    resolving=true;
                    try{nsd.resolveService(service,new NsdManager.ResolveListener(){
                        @Override public void onServiceResolved(NsdServiceInfo found){
                            resolving=false;
                            if(found.getHost()==null)return;
                            String ip=found.getHost().getHostAddress();
                            runOnUiThread(()->{
                                hostField.setText(ip);prefs.edit().putString("host",ip).apply();
                                showStatus("找到电视："+found.getServiceName()+" · "+ip,false);
                            });stopDiscovery();
                        }
                        @Override public void onResolveFailed(NsdServiceInfo i,int err){
                            resolving=false;showStatus("发现设备，但解析失败（"+err+"），请手动填写 IP",true);
                        }
                    });}catch(Exception ex){resolving=false;showStatus("搜索异常："+ex.getMessage(),true);}
                }
                @Override public void onServiceLost(NsdServiceInfo service){}
                @Override public void onDiscoveryStopped(String type){}
                @Override public void onStartDiscoveryFailed(String type,int err){
                    showStatus("搜索失败（"+err+"），可手动输入 IP",true);stopDiscovery();
                }
                @Override public void onStopDiscoveryFailed(String type,int err){}
            };
            nsd.discoverServices("_androidtvremote2._tcp.",NsdManager.PROTOCOL_DNS_SD,discovery);
        }catch(Exception e){discovery=null;showStatus("无法搜索："+e.getMessage(),true);}
    }
    private void stopDiscovery(){
        NsdManager.DiscoveryListener d=discovery;discovery=null;
        if(nsd!=null&&d!=null)try{nsd.stopServiceDiscovery(d);}catch(Exception ignored){}
    }
    private void showStatus(String text,boolean error){
        runOnUiThread(()->{if(statusView!=null){statusView.setText(text);statusView.setTextColor(error?0xffffa3aa:ACCENT);}});
    }

    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);
        t.setGravity(Gravity.CENTER_VERTICAL);return t;
    }
    private EditText input(String hint,String value,int type){
        EditText e=new EditText(this);e.setText(value);e.setHint(hint);
        e.setTextColor(LIGHT);e.setHintTextColor(SUB);e.setTextSize(14);
        e.setInputType(type);e.setSingleLine(true);
        e.setPadding(dp(13),dp(12),dp(13),dp(12));e.setBackground(bg(PANEL));return e;
    }
    private LinearLayout row(LinearLayout parent){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(r,new LinearLayout.LayoutParams(-1,-2));return r;
    }
    private void gap(LinearLayout parent,int h){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private void spacerButton(LinearLayout row){View v=new View(this);row.addView(v,new LinearLayout.LayoutParams(0,dp(54),1));}
    private Button button(LinearLayout parent,String label,int color,int weight,Runnable act){
        Button b=new Button(this);b.setText(label);b.setTextColor(LIGHT);b.setAllCaps(false);b.setTextSize(13);
        b.setBackground(bg(color));
        b.setPadding(dp(5),dp(8),dp(5),dp(8));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(weight==0?-1:0,dp(55),weight);
        if(parent.getChildCount()>0)p.leftMargin=dp(7);
        parent.addView(b,p);b.setOnClickListener(v->act.run());return b;
    }
    private GradientDrawable bg(int col){GradientDrawable d=new GradientDrawable();d.setColor(col);d.setCornerRadius(dp(12));return d;}
    @Override protected void onDestroy(){
        stopDiscovery();
        io.execute(()->{if(pairing!=null)pairing.close();if(remote!=null)remote.close();});
        io.shutdown();super.onDestroy();
    }
}
