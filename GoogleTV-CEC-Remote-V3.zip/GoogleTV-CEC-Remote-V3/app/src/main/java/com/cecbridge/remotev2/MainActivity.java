package com.cecbridge.remotev2;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Phone-only Google TV Remote v3; the 929 HDMI splitter remains unchanged. */
public final class MainActivity extends Activity {
    private static final int BG = 0xff000000;
    private static final int PANEL = 0xff15191b;
    private static final int LIGHT = 0xfff5f7fa;
    private static final int SUB = 0xffa8b2bc;
    private static final int ACCENT = 0xff69d8c7;
    private static final int GREEN = 0xff135948;
    private static final int RED = 0xff69303c;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private EditText hostField, pinField;
    private TextView statusView, powerView;
    private IdentityStore identity;
    private PairingClient pairing;
    private RemoteSession remote;
    private NsdManager nsd;
    private NsdManager.DiscoveryListener discovery;
    private boolean resolving = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("google_tv_remote_v2", MODE_PRIVATE);
        remote = new RemoteSession(null, new RemoteSession.Listener() {
            @Override public void status(String msg) { showStatus(msg, false); }
            @Override public void powerState(Boolean on) {
                runOnUiThread(() -> {
                    if (powerView != null) powerView.setText(on == null ? "Google TV 状态：未知"
                            : on ? "Google TV 状态：正在运行" : "Google TV 状态：待机");
                });
            }
        });
        buildUi();
        io.execute(() -> {
            try {
                identity = new IdentityStore(getApplicationContext());
                remote = createRemote();
                if (!prefs.getString("host", "").isEmpty() && !prefs.getString("tv_fingerprint", "").isEmpty()) {
                    connectInternal(prefs.getString("host", ""));
                } else showStatus("首次使用：先搜索或输入 Google TV IP，再进行配对", false);
            } catch (Exception ex) { showStatus("初始化证书失败：" + ex.getMessage(), true); }
        });
    }

    private RemoteSession createRemote() {
        return new RemoteSession(identity, new RemoteSession.Listener() {
            @Override public void status(String text) { showStatus(text, false); }
            @Override public void powerState(Boolean state) {
                runOnUiThread(() -> powerView.setText(state == null ? "Google TV 状态：未知"
                        : state ? "Google TV 状态：正在运行" : "Google TV 状态：待机"));
            }
        });
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(26), dp(20), dp(34));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = label("CEC REMOTE", 27, LIGHT, true);
        title.setLetterSpacing(.07f);
        root.addView(title);
        root.addView(label("Google TV  ·  929 分离器  ·  Samsung S61B", 12, SUB, false));
        space(root, 22);
        root.addView(label("投影机电源（CEC 联动）", 17, LIGHT, true));
        powerView = label("Google TV 状态：未知", 12, ACCENT, false);
        root.addView(powerView);
        space(root, 10);

        LinearLayout powerRow = row(root);
        button(powerRow, "CEC 开启", GREEN, 1, () -> powerSet(true));
        button(powerRow, "CEC 关闭", RED, 1, () -> powerSet(false));
        space(root, 9);
        button(root, "CEC 联动电源切换（状态未知时使用）", PANEL, 0, () -> key(26, "CEC 电源切换"));
        space(root, 8);
        root.addView(label("此处通过 Google TV 电源指令触发投影机 CEC 联动；并非独立投影机电源接口。", 12, SUB, false));
        space(root, 24);

        root.addView(label("Google TV 本机电源", 17, LIGHT, true));
        root.addView(label("发送明确的唤醒 / 待机按键；不需要读取当前开关状态。", 12, SUB, false));
        space(root, 9);
        LinearLayout tvPowerRow = row(root);
        button(tvPowerRow, "唤醒 Google TV", GREEN, 1, () -> key(224, "Google TV 唤醒"));
        button(tvPowerRow, "Google TV 待机", RED, 1, () -> key(223, "Google TV 待机"));
        space(root, 9);
        button(root, "Google TV 电源切换", PANEL, 0, () -> key(26, "Google TV 电源切换"));
        space(root, 9);
        root.addView(label("Google TV 待机可能同时关闭投影机；如果进入深度休眠后网络连接断开，唤醒可能失败。", 12, SUB, false));
        space(root, 24);

        root.addView(label("S61B 音量", 17, LIGHT, true));
        root.addView(label("走 Google TV 系统遥控路径，不经过 Kodi 或 Yatse", 12, SUB, false));
        space(root, 9);
        LinearLayout volRow = row(root);
        button(volRow, "−  音量", PANEL, 1, () -> key(25, "音量减"));
        button(volRow, "+  音量", PANEL, 1, () -> key(24, "音量加"));
        space(root, 9);
        button(root, "静音 / 取消静音", PANEL, 0, () -> key(164, "静音切换"));
        space(root, 24);

        root.addView(label("媒体播放", 17, LIGHT, true));
        space(root, 9);
        LinearLayout mediaRow = row(root);
        button(mediaRow, "上一曲", PANEL, 1, () -> key(88, "上一曲"));
        button(mediaRow, "播放 / 暂停", PANEL, 1, () -> key(85, "播放暂停"));
        button(mediaRow, "下一曲", PANEL, 1, () -> key(87, "下一曲"));
        space(root, 24);

        root.addView(label("Google TV 连接与配对", 17, LIGHT, true));
        root.addView(label("手机与 Google TV 必须连接同一局域网", 12, SUB, false));
        space(root, 9);
        hostField = input("Google TV IP，例如 192.168.1.50", prefs.getString("host", ""),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        root.addView(hostField);
        space(root, 10);
        LinearLayout connectRow = row(root);
        button(connectRow, "搜索电视", PANEL, 1, this::startDiscovery);
        button(connectRow, "连接", GREEN, 1, this::connect);
        space(root, 9);
        button(root, "首次配对（电视上会显示代码）", PANEL, 0, this::startPair);
        space(root, 9);
        pinField = input("输入电视显示的 6 位配对码", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        root.addView(pinField);
        space(root, 9);
        button(root, "确认配对码并连接", GREEN, 0, this::finishPair);
        space(root, 9);
        button(root, "忘记这台电视的配对", PANEL, 0, this::forgetPair);
        space(root, 20);
        statusView = label("准备初始化...", 13, ACCENT, false);
        statusView.setPadding(dp(13), dp(14), dp(13), dp(14));
        statusView.setBackground(bg(PANEL));
        root.addView(statusView);
        space(root, 13);
        root.addView(label("注意：已发送命令不等于设备实际响应；状态来自 Google TV，不是投影机独立传感器。投影机与 Google TV 的电源控制都可能产生 CEC 联动。", 12, SUB, false));
    }

    private void connect() {
        String host = saveHost();
        if (host == null) return;
        io.execute(() -> connectInternal(host));
    }

    private void connectInternal(String host) {
        if (identity == null) { showStatus("加密身份尚未就绪", true); return; }
        String fingerprint = prefs.getString("tv_fingerprint", "");
        if (fingerprint.isEmpty()) { showStatus("请先首次配对，并输入电视显示的代码", true); return; }
        try {
            showStatus("正在连接 Google TV：" + host, false);
            remote.connect(host, fingerprint);
            showStatus("已连接。可测试 S61B 音量、Google TV 本机电源与投影机 CEC 联动。", false);
        } catch (Exception ex) { showStatus("连接失败：" + ex.getMessage(), true); }
    }

    private void startPair() {
        String host = saveHost();
        if (host == null) return;
        io.execute(() -> {
            try {
                if (identity == null) throw new IllegalStateException("证书仍在初始化");
                if (pairing != null) pairing.close();
                remote.close();
                pairing = new PairingClient(identity);
                showStatus("正在请求电视显示配对码...", false);
                pairing.begin(host);
                showStatus("电视应已显示 6 位代码；请在下方输入并确认", false);
            } catch (Exception ex) { showStatus("开始配对失败：" + ex.getMessage(), true); }
        });
    }

    private void finishPair() {
        String pin = pinField.getText().toString().trim();
        String host = saveHost();
        if (host == null) return;
        if (!pin.matches("(?i)[0-9a-f]{6}")) {
            showStatus("配对码必须是 6 位字符（0-9、A-F）", true);
            return;
        }
        io.execute(() -> {
            try {
                if (pairing == null) throw new IllegalStateException("必须先点击首次配对");
                String fp = pairing.finish(pin);
                prefs.edit().putString("tv_fingerprint", fp).apply();
                runOnUiThread(() -> pinField.setText(""));
                showStatus("电视配对成功，正在连接遥控服务...", false);
                connectInternal(host);
            } catch (Exception ex) { showStatus("配对失败：" + ex.getMessage() + "。可重新点击首次配对。", true); }
        });
    }

    private void forgetPair() {
        io.execute(() -> {
            if (pairing != null) pairing.close();
            if (remote != null) remote.close();
            prefs.edit().remove("tv_fingerprint").apply();
            showStatus("已清除本 App 的配对记录；重新使用需配对", false);
            runOnUiThread(() -> powerView.setText("Google TV 状态：未知"));
        });
    }

    private void key(int key, String name) {
        String host = saveHost();
        if (host == null) return;
        io.execute(() -> {
            try {
                ensureConnected(host);
                remote.sendKey(key);
                showStatus("已发送「" + name + "」指令，请观察实际设备是否响应", false);
            } catch (Exception ex) { showStatus("无法发送「" + name + "」：" + ex.getMessage(), true); }
        });
    }

    private void powerSet(boolean targetOn) {
        String host = saveHost();
        if (host == null) return;
        io.execute(() -> {
            try {
                ensureConnected(host);
                Boolean reported = remote.isOn();
                if (reported == null) {
                    showStatus("电源状态未知：为了避免误开/误关，请使用「电源切换」按钮", true);
                    return;
                }
                if (reported == targetOn) {
                    showStatus("Google TV 已报告" + (targetOn ? "运行中" : "待机") + "，不重复切换", false);
                    return;
                }
                remote.sendKey(26); // POWER is a toggle, not a discrete ON/OFF code
                showStatus("已请求 Google TV " + (targetOn ? "唤醒" : "待机") + "，请确认投影机同步动作", false);
            } catch (Exception ex) { showStatus("电源命令失败：" + ex.getMessage(), true); }
        });
    }

    private void ensureConnected(String host) throws Exception {
        if (remote == null || identity == null) throw new IllegalStateException("初始化尚未完成");
        if (!remote.isReady()) {
            String fp = prefs.getString("tv_fingerprint", "");
            if (fp.isEmpty()) throw new IllegalStateException("请先配对电视");
            remote.connect(host, fp);
        }
    }

    private String saveHost() {
        String host = hostField.getText().toString().trim();
        // Restrict to IP or local hostnames; no arbitrary URI is accepted.
        if (host.isEmpty() || host.contains("://") || host.contains("/") || host.contains(" ")) {
            showStatus("请输入正确的 Google TV IP 地址", true);
            return null;
        }
        prefs.edit().putString("host", host).apply();
        return host;
    }

    private void startDiscovery() {
        try {
            if (discovery != null) {
                showStatus("正在搜索 Google TV...", false);
                return;
            }
            nsd = (NsdManager) getSystemService(Context.NSD_SERVICE);
            discovery = new NsdManager.DiscoveryListener() {
                @Override public void onDiscoveryStarted(String type) { showStatus("正在局域网搜索 Google TV...", false); }
                @Override public void onServiceFound(NsdServiceInfo service) {
                    if (resolving) return;
                    resolving = true;
                    try {
                        nsd.resolveService(service, new NsdManager.ResolveListener() {
                            @Override public void onServiceResolved(NsdServiceInfo found) {
                                resolving = false;
                                if (found.getHost() == null) return;
                                String ip = found.getHost().getHostAddress();
                                runOnUiThread(() -> {
                                    hostField.setText(ip);
                                    prefs.edit().putString("host", ip).apply();
                                    showStatus("发现 Google TV：" + found.getServiceName() + " · " + ip, false);
                                });
                                stopDiscovery();
                            }
                            @Override public void onResolveFailed(NsdServiceInfo svc, int error) {
                                resolving = false;
                                showStatus("自动发现解析失败，可手动填 IP（错误 " + error + "）", true);
                            }
                        });
                    } catch (Exception ex) {
                        resolving = false;
                        showStatus("自动发现异常：" + ex.getMessage(), true);
                    }
                }
                @Override public void onServiceLost(NsdServiceInfo service) { }
                @Override public void onDiscoveryStopped(String type) { }
                @Override public void onStartDiscoveryFailed(String type, int err) {
                    showStatus("搜索失败，可直接输入 Google TV IP（" + err + "）", true);
                    stopDiscovery();
                }
                @Override public void onStopDiscoveryFailed(String type, int err) { }
            };
            nsd.discoverServices("_androidtvremote2._tcp.", NsdManager.PROTOCOL_DNS_SD, discovery);
        } catch (Exception ex) { discovery = null; showStatus("无法搜索：" + ex.getMessage(), true); }
    }

    private void stopDiscovery() {
        NsdManager.DiscoveryListener toStop = discovery;
        discovery = null;
        if (nsd != null && toStop != null) {
            try { nsd.stopServiceDiscovery(toStop); } catch (Exception ignored) { }
        }
    }

    private void showStatus(String msg, boolean error) {
        runOnUiThread(() -> {
            if (statusView == null) return;
            statusView.setText(msg);
            statusView.setTextColor(error ? 0xffffa4a8 : ACCENT);
        });
    }

    private LinearLayout row(LinearLayout parent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(row, new LinearLayout.LayoutParams(-1, -2));
        return row;
    }
    private TextView label(String text, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(color);
        view.setTextSize(sp);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }
    private EditText input(String hint, String value, int type) {
        EditText view = new EditText(this);
        view.setText(value);
        view.setHint(hint);
        view.setTextColor(LIGHT);
        view.setHintTextColor(SUB);
        view.setTextSize(14);
        view.setSingleLine(true);
        view.setInputType(type);
        view.setPadding(dp(12), dp(10), dp(12), dp(10));
        view.setBackground(bg(PANEL));
        return view;
    }
    private void button(LinearLayout parent, String text, int color, int weight, Runnable action) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(LIGHT);
        btn.setAllCaps(false);
        btn.setTextSize(13);
        btn.setPadding(dp(6), dp(10), dp(6), dp(10));
        btn.setBackground(bg(color));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(weight == 0 ? -1 : 0, dp(53), weight);
        if (parent.getChildCount() > 0) p.leftMargin = dp(8);
        parent.addView(btn, p);
        btn.setOnClickListener(v -> action.run());
    }
    private GradientDrawable bg(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(11));
        return g;
    }
    private void space(LinearLayout root, int h) {
        TextView gap = new TextView(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, dp(h)));
    }
    private int dp(int value) { return Math.round(getResources().getDisplayMetrics().density * value); }

    @Override protected void onDestroy() {
        stopDiscovery();
        io.execute(() -> {
            if (pairing != null) pairing.close();
            if (remote != null) remote.close();
        });
        io.shutdown();
        super.onDestroy();
    }
}
