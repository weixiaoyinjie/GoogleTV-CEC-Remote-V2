package com.cecbridge.remotev2;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLSocket;

/** An authenticated Remote v2 session with ping replies, feature negotiation and state. */
public final class RemoteSession implements AutoCloseable {
    public interface Listener {
        void status(String status);
        void powerState(Boolean isOn);
    }

    private final IdentityStore identity;
    private final Listener listener;
    private final Object sendLock = new Object();
    private volatile SSLSocket socket;
    private volatile Boolean isOn;
    private volatile boolean ready;
    private volatile int featureMask = 611; // PING, KEY, POWER, VOLUME, APP_LINK
    private CountDownLatch readyLatch = new CountDownLatch(1);

    public RemoteSession(IdentityStore identity, Listener listener) {
        this.identity = identity;
        this.listener = listener;
    }

    public Boolean isOn() { return isOn; }
    public boolean isReady() { return ready && socket != null && !socket.isClosed(); }

    public void connect(String host, String expectedFingerprint) throws Exception {
        close();
        SSLSocket s = identity.connect(host, 6466);
        try {
            String actual = IdentityStore.fingerprint(IdentityStore.serverCert(s));
            if (!actual.equalsIgnoreCase(expectedFingerprint))
                throw new SecurityException("设备证书变化，已阻止发送；请重新配对");
            s.setSoTimeout(0); // remote service sends periodic keepalives
            socket = s;
            readyLatch = new CountDownLatch(1);
            isOn = null;
            Thread reader = new Thread(() -> readLoop(s), "cec-remote-reader");
            reader.setDaemon(true);
            reader.start();
            if (!readyLatch.await(6, TimeUnit.SECONDS) || !isReady()) {
                throw new IOException("Google TV 未完成遥控协议初始化");
            }
        } catch (Exception ex) {
            try { s.close(); } catch (Exception ignored) { }
            if (socket == s) socket = null;
            throw ex;
        }
    }

    private void readLoop(SSLSocket s) {
        try {
            while (!s.isClosed()) {
                Map<Integer, Object> packet = Proto.parse(Proto.receive(s.getInputStream()));
                if (Proto.has(packet, 1)) { // Server's RemoteConfigure
                    long supported = Proto.number(Proto.sub(packet, 1), 1);
                    featureMask = (int) supported & 611;
                    byte[] info = Proto.cat(Proto.uint(3, 1), Proto.str(4, "1"),
                            Proto.str(5, "com.cecbridge.remotev2"), Proto.str(6, "2.0"));
                    sendPacket(Proto.bytes(1, Proto.cat(Proto.uint(1, featureMask), Proto.bytes(2, info))));
                } else if (Proto.has(packet, 2)) { // server set_active
                    sendPacket(Proto.bytes(2, Proto.uint(1, featureMask)));
                } else if (Proto.has(packet, 8)) { // server ping
                    long id = Proto.number(Proto.sub(packet, 8), 1);
                    sendPacket(Proto.bytes(9, Proto.uint(1, id)));
                } else if (Proto.has(packet, 40)) { // power status
                    isOn = Proto.number(Proto.sub(packet, 40), 1) != 0;
                    listener.powerState(isOn);
                    if (!ready) {
                        ready = true;
                        readyLatch.countDown();
                        listener.status("已连接 Google TV · 等待按键");
                    }
                } else if (Proto.has(packet, 3)) {
                    listener.status("电视报告遥控协议错误，请重新配对");
                }
                // Some firmware responds with set_active rather than remote_start.
                if (!ready && (Proto.has(packet, 2) || Proto.has(packet, 1))) {
                    ready = true;
                    readyLatch.countDown();
                    listener.status("已连接 Google TV · 电源状态检测中");
                }
            }
        } catch (Exception ex) {
            if (socket == s) listener.status("连接中断，可点击连接重试：" + ex.getMessage());
        } finally {
            if (socket == s) {
                ready = false;
                socket = null;
                isOn = null;
                listener.powerState(null);
            }
            readyLatch.countDown();
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    private void sendPacket(byte[] body) throws IOException {
        synchronized (sendLock) {
            SSLSocket s = socket;
            if (s == null || s.isClosed()) throw new IOException("Google TV 未连接");
            Proto.send(s.getOutputStream(), body);
        }
    }

    public void sendKey(int androidKeyCode) throws IOException {
        if (!isReady()) throw new IOException("Google TV 未完成连接");
        // Android RemoteKeyInject { key_code = 1, direction = 2 (SHORT=3) }
        sendPacket(Proto.bytes(10, Proto.cat(Proto.uint(1, androidKeyCode), Proto.uint(2, 3))));
    }

    @Override public void close() {
        SSLSocket s = socket;
        ready = false;
        isOn = null;
        socket = null;
        readyLatch.countDown();
        if (s != null) try { s.close(); } catch (Exception ignored) { }
    }
}
