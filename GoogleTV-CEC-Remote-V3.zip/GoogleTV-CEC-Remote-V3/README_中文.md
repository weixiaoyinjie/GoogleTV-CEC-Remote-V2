# Google TV CEC Remote V3（手机端独立版）

这是针对以下已验证硬件链路制作的 Android 手机 App 源码：

**手机 Wi-Fi → Google TV → 929 HDMI 音频分离器 → 投影机 + Samsung HW-S61B**

用户已在 Google TV 官方手机遥控器中实际验证：音量 ± 可改变 S61B 的实际音量，电源键可打开/关闭投影机。V3 不需要 Kodi、Yatse、Root、ADB 或电视侧额外 App。

> 这是待 GitHub Actions 编译和实机测试的源码工程，不是经设备验证的成品 APK；已发送指令不保证投影机收到。

## 包含功能

- Google TV Remote Protocol v2：TLS 配对和控制。
- 支持通过 mDNS 搜索 `_androidtvremote2._tcp.`，或手动输入 IP。
- 首次配对时，输入电视屏幕上的 6 位十六进制配对码。
- 记住身份凭据；二次打开自动尝试连接。
- 使用手机按键命令控制 S61B 音量加减、静音。
- 投影机 CEC 联动电源：根据 Google TV 报告状态，只有必要时发送 `KEYCODE_POWER=26`，另外有手动切换按钮。
- **新增 Google TV 本机电源控制：**“唤醒 Google TV”发送 `KEYCODE_WAKEUP=224`；“Google TV 待机”发送 `KEYCODE_SLEEP=223`；“Google TV 电源切换”发送 `KEYCODE_POWER=26`。这几个按钮不需要先读取状态。
- **关键限制：**两组电源按钮都是经 Google TV 系统发出的按键。待机、唤醒都可能通过 HDMI-CEC 影响投影机，不能宣称可独立控制 Google TV 与投影机。`SLEEP` 也不是物理断电。
- 播放 / 暂停、上一曲、下一曲。
- 配对时用显示的 PIN 核实 RSA 证书。连接时比对上次配对的设备证书 SHA-256 指纹。
- 黑色 AMOLED 简约界面。

## 第一次使用

1. Google TV 和手机连同一局域网，Google TV 正常开启。
2. 安装编译的 APK，按“搜索电视”或手动输入 Google TV 局域网 IP。
3. 点击“首次配对”，Google TV 屏幕会显示 6 位代码。
4. 在手机输入代码，点击“确认配对码并连接”。
5. 先测试 S61B 音量，再测试新增的“Google TV 本机电源”，最后测试投影机 CEC 联动开关。手机原装遥控器可以继续使用。

可能个别电视固件无法报告电源状态，此时“开启/关闭”保护性拒绝猜测，改按“电源切换”按钮。

## GitHub Actions 编译

新建仓库建议 `GoogleTV-CEC-Remote-V3`。**解压 ZIP 后把所有文件上传仓库根目录（包含隐藏的 `.github` 文件夹）**。进入仓库 Actions → Build Android APK → Run workflow（或推送到 main 自动启动）。

编译任务会生成 `CEC-Remote-V3-debug-APK` Artifact，其中包含 `app-debug.apk`。

## 协议

- 6467/TLS：Polo pairing protocol；先校验编码协商及电视端配对码。
- 6466/TLS：Google TV Remote v2，带长度 varint 的 protobuf 帧。
- `KEYCODE_POWER=26` 是电源切换，不是专用开关。
- `KEYCODE_SLEEP=223` 是待机（已待机时无动作）；`KEYCODE_WAKEUP=224` 是唤醒（已唤醒时无动作），具体硬件和固件仍需实机测试。
- `KEYCODE_VOLUME_UP=24`, `KEYCODE_VOLUME_DOWN=25`, `KEYCODE_VOLUME_MUTE=164`。
- PIN 经 SHA-256(client RSA modulus + client exponent + server modulus + server exponent + code[2:]) 验证；凭据留在 app 私有存储。

协议参考：
- https://github.com/tronikos/androidtvremote2
- https://github.com/drosoCode/atvremote

## 排查

- 同一 Wi-Fi/局域网，路由器不要启用 AP 隔离；Google TV 需安装 Android TV Remote Service。
- 如果发现失败：在 Google TV 系统设置里查设备 IP，手动填入。
- 已配对但连接失败：电视服务重启、IP 变化或系统更新均有可能，先手动连接；若设备证书改变需重新配对。
- 处于深度待机或无网络供电时，6466 端口可能不可达。该限制与通过 HDMI CEC 是否能唤醒投影机是两回事。
- 929 分离器的实际 CEC 转发已经由官方遥控器验证，但本 App 首次使用仍必须测试。

## 当前版本限制

- 没有直接调用 Samsung S61B 的私有接口，也没有直接绕过 Google TV 去控制投影机。
- Google TV 报告的 `remote_start` 是 Google TV 状态，不是投影机实际电源遥测。
- 若 Google TV 因深度休眠无法接收网络遥控，手机无法保证唤醒；`KEYCODE_WAKEUP` 需要网络遥控服务可达。
- `Google TV 本机电源`与`投影机 CEC 联动`的按键不能保证仅影响单个设备。
- 如果用新 GitHub Actions 运行环境生成的 debug APK 无法覆盖旧版（签名不同），请卸载旧版再装新版；会丢失本 App 的本地配对，需要重新配对。
- 尚未在用户的 Google TV 上完成配对、编译或硬件实测。

## V3 变更记录（2026-11-11）

- 在现有 V2 基础上新增 Google TV 自身「唤醒」「待机」「电源切换」按钮。
- 投影机按键改标「CEC 联动」，避免将 Google TV 电源状态误写为投影机独立状态。
- 保留现有的 S61B 音量/静音、媒体按键、局域网配对和自动重连。
- APK versionCode 升级到 3；原 Android 包名不变。
