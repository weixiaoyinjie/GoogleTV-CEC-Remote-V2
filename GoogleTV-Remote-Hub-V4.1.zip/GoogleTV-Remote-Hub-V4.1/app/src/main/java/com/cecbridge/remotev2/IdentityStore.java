package com.cecbridge.remotev2;

import android.content.Context;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.util.Arrays;
import java.util.Date;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.net.ssl.SSLSocket;
import java.net.InetSocketAddress;
import java.net.Socket;

/** Per-install RSA identity; PKCS12 stays in app-private storage and is never exported. */
public final class IdentityStore {
    private static final char[] STORE_PASSWORD = "local-cec-identity".toCharArray();
    private final File file;
    private final KeyStore store;

    public IdentityStore(Context ctx) throws Exception {
        file = new File(ctx.getFilesDir(), "remote-client.p12");
        store = KeyStore.getInstance("PKCS12");
        if (file.exists()) {
            try (FileInputStream input = new FileInputStream(file)) { store.load(input, STORE_PASSWORD); }
        } else {
            store.load(null, STORE_PASSWORD);
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            generator.initialize(2048, new SecureRandom());
            KeyPair pair = generator.generateKeyPair();
            Date from = new Date(System.currentTimeMillis() - 24L * 3600_000L);
            Date until = new Date(System.currentTimeMillis() + 5L * 365 * 24 * 3600_000L);
            X500Name name = new X500Name("CN=CEC Remote V2");
            BouncyCastleProvider provider = new BouncyCastleProvider();
            JcaX509v3CertificateBuilder builder = new JcaX509v3CertificateBuilder(
                    name, new BigInteger(80, new SecureRandom()), from, until, name, pair.getPublic());
            ContentSigner signer = new JcaContentSignerBuilder("SHA256withRSA")
                    .setProvider(provider).build(pair.getPrivate());
            X509CertificateHolder holder = builder.build(signer);
            X509Certificate cert = new JcaX509CertificateConverter().setProvider(provider).getCertificate(holder);
            store.setKeyEntry("phone", pair.getPrivate(), STORE_PASSWORD, new java.security.cert.Certificate[]{cert});
            try (FileOutputStream output = new FileOutputStream(file)) { store.store(output, STORE_PASSWORD); }
        }
    }

    public X509Certificate clientCertificate() throws Exception {
        return (X509Certificate) store.getCertificate("phone");
    }

    public SSLSocket connect(String host, int port) throws Exception {
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(store, STORE_PASSWORD);
        X509TrustManager pairingTrustManager = new X509TrustManager() {
            @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            @Override public void checkClientTrusted(X509Certificate[] chain, String authType) { }
            // Devices use untrusted self-signed certs; pairing code authenticates the key.
            @Override public void checkServerTrusted(X509Certificate[] chain, String authType) { }
        };
        SSLContext context = SSLContext.getInstance("TLS");
        context.init(kmf.getKeyManagers(), new TrustManager[]{pairingTrustManager}, new SecureRandom());
        Socket raw = new Socket();
        try {
            raw.connect(new InetSocketAddress(host, port), 4000);
            raw.setSoTimeout(8000);
            SSLSocket socket = (SSLSocket) context.getSocketFactory().createSocket(raw, host, port, true);
            java.util.ArrayList<String> enabled = new java.util.ArrayList<>();
            java.util.List<String> supported = java.util.Arrays.asList(socket.getSupportedProtocols());
            if (supported.contains("TLSv1.3")) enabled.add("TLSv1.3");
            if (supported.contains("TLSv1.2")) enabled.add("TLSv1.2");
            socket.setEnabledProtocols(enabled.toArray(new String[0]));
            socket.startHandshake();
            return socket;
        } catch (Exception ex) {
            try { raw.close(); } catch (Exception ignored) { }
            throw ex;
        }
    }

    public static X509Certificate serverCert(SSLSocket socket) throws Exception {
        return (X509Certificate) socket.getSession().getPeerCertificates()[0];
    }

    public static String fingerprint(X509Certificate cert) throws Exception {
        byte[] sum = MessageDigest.getInstance("SHA-256").digest(cert.getEncoded());
        StringBuilder sb = new StringBuilder();
        for (byte b : sum) sb.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
        return sb.toString();
    }

    public static byte[] rsaUnsigned(BigInteger number) {
        byte[] b = number.toByteArray();
        return b.length > 1 && b[0] == 0 ? Arrays.copyOfRange(b, 1, b.length) : b;
    }

    public static byte[] pairingSecret(X509Certificate client, X509Certificate server, String pin) throws Exception {
        if (!pin.matches("(?i)[0-9a-f]{6}")) throw new IllegalArgumentException("配对码必须是 6 位十六进制字符");
        RSAPublicKey a = (RSAPublicKey) client.getPublicKey();
        RSAPublicKey b = (RSAPublicKey) server.getPublicKey();
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        sha.update(rsaUnsigned(a.getModulus()));
        sha.update(rsaUnsigned(a.getPublicExponent()));
        sha.update(rsaUnsigned(b.getModulus()));
        sha.update(rsaUnsigned(b.getPublicExponent()));
        for (int i = 2; i < 6; i += 2) sha.update((byte) Integer.parseInt(pin.substring(i, i + 2), 16));
        byte[] digest = sha.digest();
        if ((digest[0] & 255) != Integer.parseInt(pin.substring(0, 2), 16))
            throw new IllegalArgumentException("配对码校验失败：请重新核对电视屏幕上的字符");
        return digest;
    }
}
