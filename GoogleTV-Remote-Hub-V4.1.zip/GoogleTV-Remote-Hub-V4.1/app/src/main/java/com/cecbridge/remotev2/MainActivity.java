package com.cecbridge.remotev2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Phone-only remote controller for Google TV via Remote v2; no CEC code. */
public final class MainActivity extends Activity {
    private static final int BG=0xff08090b, PANEL=0xff181b20, LIGHT=0xfff5f7fa,
            SUB=0xffaab2bd, ACCENT=0xff62d0c0, GREEN=0xff176657, RED=0xff713744;
    private static final String PREFS="google_tv_remote_v2"; // keep V3 pairing data
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final List<SavedApp> savedApps=new ArrayList<>();
    private SharedPreferences prefs;
    private EditText hostField, pinField;
    private TextView statusView, powerView;
    private LinearLayout appsGrid;
    private IdentityStore identity;
    private PairingClient pairing;
    private RemoteSession remote;
    private NsdManager nsd;
    private NsdManager.DiscoveryListener discovery;
    private volatile boolean resolving;

    private static final class SavedApp {
        String name, target;
        SavedApp(String n,String t){name=n;target=t;}
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        restoreApps();
        buildUi();
        io.execute(() -> {
            try {
                identity=new IdentityStore(getApplicationContext());
                remote=createRemote();
                String host=prefs.getString("host", "");
                if(!host.isEmpty()&&!prefs.getString("tv_fingerprint", "").isEmpty())
                    connectInternal(host);
                else showStatus("首次使用：输入电视 IP，点击首次配对，并填写电视上的六位配对码",false);
            } catch(Exception e) { showStatus("初始化失败："+e.getMessage(),true); }
        });
    }

    private RemoteSession createRemote(){
        return new RemoteSession(identity,new RemoteSession.Listener(){
            @Override public void status(String s){showStatus(s,false);}
            @Override public void powerState(Boolean on){
                runOnUiThread(() -> {
                    if(powerView!=null)powerView.setText(on==null?"Google TV · 状态未知":
                            on?"Google TV · 正在运行":"Google TV · 待机");
                });
            }
        });
    }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(19),dp(22),dp(19),dp(42));
        scroll.addView(root);
        setContentView(scroll);

        TextView title=label("TV REMOTE",28,LIGHT,true);
        title.setLetterSpacing(.075f);
        root.addView(title);
        root.addView(label("Google TV  ·  仅手机安装  ·  局域网遥控",12,SUB,false));
        gap(root,19);

        root.addView(label("Google TV 电源",18,LIGHT,true));
        powerView=label("Google TV · 尚未连接",13,ACCENT,false);
        root.addView(powerView);
        gap(root,9);
        LinearLayout powerRow=row(root);
        button(powerRow,"开机 / 唤醒",GREEN,1,() -> key(224,"Google TV 唤醒"));
        button(powerRow,"关机 / 待机",RED,1,() -> key(223,"Google TV 待机"));
        gap(root,8);
        button(root,"电源切换",PANEL,0,()->key(26,"电源切换"));
        root.addView(label("关机为待机，不会切断 Google TV 电源。深度待机后若 Wi-Fi 断开，手机可能无法唤醒。",11,SUB,false));
        gap(root,13);

        root.addView(label("手机桌面快捷方式",18,LIGHT,true));
        root.addView(label("像 SP3 快捷开关一样，添加到手机桌面后点击即可发送 Google TV 电源命令，不打开整页遥控器。",12,SUB,false));
        gap(root,8);
        LinearLayout shortcutRow=row(root);
        button(shortcutRow,"＋ 桌面关机",RED,1,()->pinPowerShortcut(QuickActionActivity.ACTION_SLEEP,"tv-sleep","关闭 Google TV",R.drawable.ic_shortcut_sleep));
        button(shortcutRow,"＋ 桌面开机",GREEN,1,()->pinPowerShortcut(QuickActionActivity.ACTION_WAKE,"tv-wake","唤醒 Google TV",R.drawable.ic_shortcut_wake));
        gap(root,7);
        button(root,"＋ 桌面电源切换",PANEL,0,()->pinPowerShortcut(QuickActionActivity.ACTION_TOGGLE,"tv-toggle","Google TV 开关",R.drawable.ic_shortcut_toggle));
        root.addView(label("添加时 Android 会让你确认放到主屏幕；一键关机实际是待机，手机需要和电视在同一局域网。",11,SUB,false));
        gap(root,23);

        root.addView(label("电视 App 快捷启动",18,LIGHT,true));
        root.addView(label("点击按钮向电视发送启动请求；长按按钮可修改或删除。",12,SUB,false));
        gap(root,9);
        appsGrid=new LinearLayout(this);appsGrid.setOrientation(LinearLayout.VERTICAL);
        root.addView(appsGrid);
        renderApps();
        gap(root,8);
        button(root,"＋ 添加电视 App",PANEL,0,()->editApp(-1));
        gap(root,10);
        root.addView(label("Google Play 备用启动方式",15,LIGHT,true));
        root.addView(label("一键启动若只打开 Play 商店：选中对应 App 的商店详情页，在电视上选择「打开」，再用手机点下方「确定」。",12,SUB,false));
        gap(root,7);
        LinearLayout storeRow=row(root);
        button(storeRow,"打开电视 Play 商店详情",PANEL,1,this::chooseStoreApp);
        button(storeRow,"确定 / 打开",GREEN,1,()->key(23,"电视确定键"));
        gap(root,6);
        root.addView(label("包名按钮先尝试 Play 商店的应用启动入口；不保证能绕过商店详情页。自定义 App 可输入包名或专用启动链接。",11,SUB,false));
        gap(root,23);

        root.addView(label("媒体控制面板",18,LIGHT,true));
        root.addView(label("适用于支持系统媒体按键的视频／音乐播放器；实际效果由电视端 App 决定。",12,SUB,false));
        gap(root,9);
        LinearLayout transport=row(root);
        button(transport,"⏮ 上一个",PANEL,1,()->key(88,"上一个"));
        button(transport,"▶ / ❚❚",GREEN,1,()->key(85,"播放/暂停"));
        button(transport,"下一个 ⏭",PANEL,1,()->key(87,"下一个"));
        gap(root,9);
        LinearLayout ff=row(root);
        button(ff,"⏪ 快退",PANEL,1,()->key(89,"快退"));
        button(ff,"⏩ 快进",PANEL,1,()->key(90,"快进"));
        gap(root,9);
        LinearLayout alt=row(root);
        button(alt,"◀ 左方向/回退",PANEL,1,()->key(21,"左方向"));
        button(alt,"右方向/前进 ▶",PANEL,1,()->key(22,"右方向"));
        gap(root,9);
        button(root,"■ 停止播放",PANEL,0,()->key(86,"停止播放"));
        root.addView(label("不同播放器对快进键和方向键的定义不同；方向键不保证精确跳转秒数，不能直接访问播放器的内部播放列表。",11,SUB,false));
        gap(root,23);

        root.addView(label("电视方向遥控",18,LIGHT,true));
        gap(root,10);
        LinearLayout up=row(root);
        spacerButton(up);button(up,"▲",PANEL,1,()->key(19,"向上"));spacerButton(up);
        gap(root,5);
        LinearLayout center=row(root);
        button(center,"◀",PANEL,1,()->key(21,"向左"));
        button(center,"确定",GREEN,1,()->key(23,"确定"));
        button(center,"▶",PANEL,1,()->key(22,"向右"));
        gap(root,5);
        LinearLayout down=row(root);
        spacerButton(down);button(down,"▼",PANEL,1,()->key(20,"向下"));spacerButton(down);
        gap(root,9);
        LinearLayout nav=row(root);
        button(nav,"返回",PANEL,1,()->key(4,"返回"));
        button(nav,"主页",PANEL,1,()->key(3,"主页"));
        button(nav,"菜单",PANEL,1,()->key(82,"菜单"));
        gap(root,26);

        root.addView(label("连接与首次配对",18,LIGHT,true));
        root.addView(label("手机和 Google TV 位于同一局域网，配对凭据会保存在本机。",12,SUB,false));
        gap(root,9);
        hostField=input("Google TV IP，例如 192.168.0.52",prefs.getString("host",""),
                InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        root.addView(hostField);
        gap(root,9);
        LinearLayout con=row(root);
        button(con,"搜索电视",PANEL,1,this::startDiscovery);
        button(con,"连接电视",GREEN,1,this::connect);
        gap(root,9);
        button(root,"首次配对（电视显示六位代码）",PANEL,0,this::startPair);
        gap(root,9);
        pinField=input("输入电视显示的六位配对码","",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        root.addView(pinField);
        gap(root,9);
        button(root,"确认配对码并连接",GREEN,0,this::finishPair);
        gap(root,9);
        button(root,"忘记此电视的配对",PANEL,0,this::forgetPair);
        gap(root,18);
        statusView=label("正在初始化遥控器…",12,ACCENT,false);
        statusView.setPadding(dp(14),dp(14),dp(14),dp(14));
        statusView.setBackground(bg(PANEL));root.addView(statusView);
        gap(root,10);
        root.addView(label("本 App 不控制 HDMI-CEC，也不需要在电视端另装 App。电视程序启动与媒体按键属于尽力发送，需以电视实际反应为准。",11,SUB,false));
    }

    private void restoreApps(){
        String saved=prefs.getString("custom_tv_apps_v4",null);
        if(saved==null){
            savedApps.add(new SavedApp("Kodi","org.xbmc.kodi"));
            savedApps.add(new SavedApp("Qobuz","com.qobuz.music"));
            return;
        }
        try{
            JSONArray array=new JSONArray(saved);
            for(int i=0;i<array.length();i++){
                JSONObject obj=array.getJSONObject(i);
                String name=obj.optString("name","").trim();
                String target=obj.optString("target","").trim();
                if(!name.isEmpty()&&!target.isEmpty())savedApps.add(new SavedApp(name,target));
            }
        }catch(Exception ignored){
            savedApps.clear();
            savedApps.add(new SavedApp("Kodi","org.xbmc.kodi"));
            savedApps.add(new SavedApp("Qobuz","com.qobuz.music"));
        }
    }
    private void persistApps(){
        JSONArray json=new JSONArray();
        for(SavedApp a:savedApps){
            JSONObject o=new JSONObject();
            try{o.put("name",a.name);o.put("target",a.target);}catch(Exception ignored){}
            json.put(o);
        }
        prefs.edit().putString("custom_tv_apps_v4",json.toString()).apply();
    }
    private void renderApps(){
        if(appsGrid==null)return;
        appsGrid.removeAllViews();
        for(int i=0;i<savedApps.size();i+=2){
            LinearLayout r=row(appsGrid);
            for(int j=i;j<Math.min(i+2,savedApps.size());j++){
                final int at=j;
                SavedApp item=savedApps.get(j);
                Button btn=button(r,item.name,at<2?GREEN:PANEL,1,()->launch(item));
                btn.setOnLongClickListener(v->{editApp(at);return true;});
            }
            if(i+1>=savedApps.size())spacerButton(r);
            gap(appsGrid,9);
        }
        if(savedApps.isEmpty())appsGrid.addView(label("还没有快捷 App，点击下方添加。",12,SUB,false));
    }
    private void editApp(int index){
        boolean editing=index>=0&&index<savedApps.size();
        SavedApp old=editing?savedApps.get(index):new SavedApp("","");
        LinearLayout fields=new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(dp(18),dp(14),dp(18),0);
        EditText name=input("显示名称，例如 MX Player",old.name,InputType.TYPE_CLASS_TEXT);
        fields.addView(name);
        gap(fields,9);
        EditText target=input("包名或启动链接",old.target,InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        fields.addView(target);
        TextView hint=label("包名示例：org.xbmc.kodi；或者粘贴 App 支持的 https:// 深度链接。",12,SUB,false);
        gap(fields,8);fields.addView(hint);
        AlertDialog.Builder builder=new AlertDialog.Builder(this).setTitle(editing?"修改电视 App 快捷方式":"添加电视 App")
                .setView(fields).setNegativeButton("取消",null)
                .setPositiveButton("保存",null);
        if(editing)builder.setNeutralButton("删除",(d,w)->{
            savedApps.remove(index);persistApps();renderApps();
        });
        AlertDialog dialog=builder.create();dialog.setOnShowListener(v->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2->{
                    String n=name.getText().toString().trim();
                    String t=target.getText().toString().trim();
                    if(n.isEmpty()||n.length()>32||!validTarget(t)){
                        Toast.makeText(this,"请填写名称和有效的包名或链接",Toast.LENGTH_LONG).show();return;
                    }
                    if(editing){savedApps.get(index).name=n;savedApps.get(index).target=t;}
                    else savedApps.add(new SavedApp(n,t));
                    persistApps();renderApps();dialog.dismiss();
                }));
        dialog.show();
    }

    private void pinPowerShortcut(String action,String id,String shortLabel,int iconId){
        String host=saveHost();if(host==null)return;
        if(prefs.getString("tv_fingerprint","").isEmpty()){
            showStatus("请先完成 Google TV 六位代码配对，再添加桌面快捷方式。",true);return;
        }
        ShortcutManager manager=getSystemService(ShortcutManager.class);
        if(manager==null||!manager.isRequestPinShortcutSupported()){
            showStatus("当前手机桌面不支持自动添加固定快捷方式，可尝试长按 App 图标查看快捷功能。",true);return;
        }
        Intent intent=new Intent(this,QuickActionActivity.class);
        intent.setAction(action);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        ShortcutInfo shortcut=new ShortcutInfo.Builder(this,id)
                .setShortLabel(shortLabel)
                .setLongLabel(shortLabel+"（Wi-Fi 遥控）")
                .setIcon(Icon.createWithResource(this,iconId))
                .setIntent(intent).build();
        try {
            if(manager.requestPinShortcut(shortcut,null))
                showStatus("请在 Android 弹出的确认窗口里添加「"+shortLabel+"」到桌面。",false);
            else showStatus("未能请求添加快捷方式，请检查当前桌面启动器。",true);
        } catch(Exception e){showStatus("无法添加桌面快捷方式："+e.getMessage(),true);}
    }

    private void chooseStoreApp(){
        ArrayList<SavedApp> packages=new ArrayList<>();
        for(SavedApp app:savedApps){
            if(app.target.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+"))packages.add(app);
        }
        if(packages.isEmpty()){
            showStatus("没有使用 Android 包名的电视 App，请先添加包名。",true);return;
        }
        String[] names=new String[packages.size()];
        for(int i=0;i<packages.size();i++)names[i]=packages.get(i).name;
        new AlertDialog.Builder(this).setTitle("在电视 Play 商店打开哪个 App 的页面？")
                .setItems(names,(d,which)->launchStoreDetail(packages.get(which)))
                .setNegativeButton("取消",null).show();
    }

    private void launchStoreDetail(SavedApp app){
        String host=saveHost();if(host==null)return;
        io.execute(()->{
            try{
                ensureConnected(host);
                remote.openAppStorePage(app.target);
                showStatus("已请求电视打开「"+app.name+"」的 Play 商店页。看到「打开」后选中它，再按手机上的「确定 / 打开」。",false);
            }catch(Exception e){showStatus("打开电视 Play 商店页面失败："+e.getMessage(),true);}
        });
    }

    private static boolean validTarget(String raw){
        if(raw==null||raw.isEmpty()||raw.length()>400||raw.contains("\n")||raw.contains(" "))return false;
        if(raw.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+"))return true;
        return raw.matches("(?i)^(https?://|[a-z][a-z0-9+.-]*://).+");
    }

    private void launch(SavedApp app){
        String host=saveHost();if(host==null)return;
        io.execute(()->{
            try{
                ensureConnected(host);
                if (Boolean.FALSE.equals(remote.isOn())) {
                    remote.sendKey(224); // wake before launch when the remote still has a session
                    try { Thread.sleep(800); } catch (InterruptedException interrupted) {
                        Thread.currentThread().interrupt();
                    }
                }
                remote.launchApp(app.target);
                showStatus("已请求电视启动「"+app.name+"」。如电视打开商店或没有反应，可长按按钮更换深度链接。",false);
            }catch(Exception e){showStatus("启动「"+app.name+"」请求失败："+e.getMessage(),true);}
        });
    }
    private void key(int code,String name){
        String host=saveHost();if(host==null)return;
        io.execute(()->{
            try{
                ensureConnected(host);
                remote.sendKey(code);
                showStatus("已发送「"+name+"」。具体响应由电视和当前播放器决定。",false);
            }catch(Exception e){showStatus("发送「"+name+"」失败："+e.getMessage(),true);}
        });
    }
    private String saveHost(){
        String host=hostField.getText().toString().trim();
        if(host.isEmpty()||host.contains("://")||host.contains("/")||host.contains(" ")||host.contains(":")){
            showStatus("请输入 Google TV 的有效 IPv4 地址或主机名",true);return null;
        }
        prefs.edit().putString("host",host).apply();return host;
    }
    private void ensureConnected(String host)throws Exception{
        if(remote==null||identity==null)throw new IllegalStateException("遥控器尚未初始化");
        if(!remote.isReady()){
            String fp=prefs.getString("tv_fingerprint","");
            if(fp.isEmpty())throw new IllegalStateException("请先完成六位码配对");
            remote.connect(host,fp);
        }
    }
    private void connect(){String host=saveHost();if(host!=null)io.execute(()->connectInternal(host));}
    private void connectInternal(String host){
        if(identity==null){showStatus("证书尚未初始化",true);return;}
        try{
            String fp=prefs.getString("tv_fingerprint","");
            if(fp.isEmpty())throw new IllegalStateException("未配对，请先输入电视显示的六位代码");
            showStatus("正在连接 Google TV："+host,false);
            remote.connect(host,fp);
            showStatus("已连接 Google TV，可以操作本机电源、启动 App 和媒体控制。",false);
        }catch(Exception e){showStatus("连接失败："+e.getMessage(),true);}
    }
    private void startPair(){
        String host=saveHost();if(host==null)return;
        io.execute(()->{
            try{
                if(identity==null)throw new IllegalStateException("证书尚未初始化");
                if(pairing!=null)pairing.close();
                if(remote!=null)remote.close();
                pairing=new PairingClient(identity);
                showStatus("请求电视显示六位配对码…",false);
                pairing.begin(host);
                showStatus("请将 Google TV 上显示的六位代码填入下方。",false);
            }catch(Exception e){showStatus("开始配对失败："+e.getMessage(),true);}
        });
    }
    private void finishPair(){
        String pin=pinField.getText().toString().trim();
        String host=saveHost();if(host==null)return;
        if(!pin.matches("(?i)[0-9a-f]{6}")){showStatus("请输入 6 位配对码（0–9 或 A–F）",true);return;}
        io.execute(()->{
            try{
                if(pairing==null)throw new IllegalStateException("请先点击首次配对");
                String fp=pairing.finish(pin);
                prefs.edit().putString("tv_fingerprint",fp).apply();
                runOnUiThread(()->pinField.setText(""));
                showStatus("配对成功，正在连接…",false);
                connectInternal(host);
            }catch(Exception e){showStatus("配对失败："+e.getMessage()+"，可以重新开始配对。",true);}
        });
    }
    private void forgetPair(){
        io.execute(()->{
            if(pairing!=null)pairing.close();
            if(remote!=null)remote.close();
            prefs.edit().remove("tv_fingerprint").apply();
            showStatus("本机配对记录已清除；再次连接需重新输入配对码。",false);
        });
    }
    private void startDiscovery(){
        try{
            if(discovery!=null){showStatus("正在搜索电视…",false);return;}
            nsd=(NsdManager)getSystemService(Context.NSD_SERVICE);
            discovery=new NsdManager.DiscoveryListener(){
                @Override public void onDiscoveryStarted(String type){showStatus("局域网搜索中…",false);}
                @Override public void onServiceFound(NsdServiceInfo service){
                    if(resolving)return;
                    resolving=true;
                    try{nsd.resolveService(service,new NsdManager.ResolveListener(){
                        @Override public void onServiceResolved(NsdServiceInfo found){
                            resolving=false;
                            if(found.getHost()==null)return;
                            String ip=found.getHost().getHostAddress();
                            runOnUiThread(()->{
                                hostField.setText(ip);prefs.edit().putString("host",ip).apply();
                                showStatus("找到电视："+found.getServiceName()+" · "+ip,false);
                            });stopDiscovery();
                        }
                        @Override public void onResolveFailed(NsdServiceInfo i,int err){
                            resolving=false;showStatus("发现设备，但解析失败（"+err+"），请手动填写 IP",true);
                        }
                    });}catch(Exception ex){resolving=false;showStatus("搜索异常："+ex.getMessage(),true);}
                }
                @Override public void onServiceLost(NsdServiceInfo service){}
                @Override public void onDiscoveryStopped(String type){}
                @Override public void onStartDiscoveryFailed(String type,int err){
                    showStatus("搜索失败（"+err+"），可手动输入 IP",true);stopDiscovery();
                }
                @Override public void onStopDiscoveryFailed(String type,int err){}
            };
            nsd.discoverServices("_androidtvremote2._tcp.",NsdManager.PROTOCOL_DNS_SD,discovery);
        }catch(Exception e){discovery=null;showStatus("无法搜索："+e.getMessage(),true);}
    }
    private void stopDiscovery(){
        NsdManager.DiscoveryListener d=discovery;discovery=null;
        if(nsd!=null&&d!=null)try{nsd.stopServiceDiscovery(d);}catch(Exception ignored){}
    }
    private void showStatus(String text,boolean error){
        runOnUiThread(()->{if(statusView!=null){statusView.setText(text);statusView.setTextColor(error?0xffffa3aa:ACCENT);}});
    }

    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);
        t.setGravity(Gravity.CENTER_VERTICAL);return t;
    }
    private EditText input(String hint,String value,int type){
        EditText e=new EditText(this);e.setText(value);e.setHint(hint);
        e.setTextColor(LIGHT);e.setHintTextColor(SUB);e.setTextSize(14);
        e.setInputType(type);e.setSingleLine(true);
        e.setPadding(dp(13),dp(12),dp(13),dp(12));e.setBackground(bg(PANEL));return e;
    }
    private LinearLayout row(LinearLayout parent){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(r,new LinearLayout.LayoutParams(-1,-2));return r;
    }
    private void gap(LinearLayout parent,int h){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private void spacerButton(LinearLayout row){View v=new View(this);row.addView(v,new LinearLayout.LayoutParams(0,dp(54),1));}
    private Button button(LinearLayout parent,String label,int color,int weight,Runnable act){
        Button b=new Button(this);b.setText(label);b.setTextColor(LIGHT);b.setAllCaps(false);b.setTextSize(13);
        b.setBackground(bg(color));
        b.setPadding(dp(5),dp(8),dp(5),dp(8));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(weight==0?-1:0,dp(55),weight);
        if(parent.getChildCount()>0)p.leftMargin=dp(7);
        parent.addView(b,p);b.setOnClickListener(v->act.run());return b;
    }
    private GradientDrawable bg(int col){GradientDrawable d=new GradientDrawable();d.setColor(col);d.setCornerRadius(dp(12));return d;}
    @Override protected void onDestroy(){
        stopDiscovery();
        io.execute(()->{if(pairing!=null)pairing.close();if(remote!=null)remote.close();});
        io.shutdown();super.onDestroy();
    }
}
