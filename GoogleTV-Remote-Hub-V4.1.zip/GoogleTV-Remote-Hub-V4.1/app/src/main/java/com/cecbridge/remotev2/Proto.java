package com.cecbridge.remotev2;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/** Small protobuf wire-format codec for Android TV Remote v2. */
public final class Proto {
    private Proto() {}

    public static byte[] uint(int field, long value) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        writeVarint(out, (long) field * 8);
        writeVarint(out, value);
        return out.toByteArray();
    }
    public static byte[] bytes(int field, byte[] value) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        writeVarint(out, (long) field * 8 + 2);
        writeVarint(out, value.length);
        out.write(value, 0, value.length);
        return out.toByteArray();
    }
    public static byte[] str(int field, String s) {
        return bytes(field, s.getBytes(StandardCharsets.UTF_8));
    }
    public static byte[] cat(byte[]... arrays) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        for (byte[] b : arrays) out.write(b, 0, b.length);
        return out.toByteArray();
    }
    public static void writeVarint(OutputStream out, long value) {
        try {
            while ((value & ~127L) != 0) {
                out.write((int) (value & 127L) | 128);
                value >>>= 7;
            }
            out.write((int) value);
        } catch (IOException ex) {
            throw new IllegalStateException(ex);
        }
    }
    public static long readVarint(InputStream in) throws IOException {
        long value = 0;
        for (int i = 0; i < 10; i++) {
            int b = in.read();
            if (b == -1) throw new EOFException("Connection closed");
            if (i == 9 && b > 1) throw new IOException("Malformed varint");
            value |= (long) (b & 127) << (7 * i);
            if ((b & 128) == 0) return value;
        }
        throw new IOException("Varint too long");
    }
    public static synchronized void send(OutputStream out, byte[] packet) throws IOException {
        if (packet.length > 1_048_576) throw new IOException("Oversized message");
        writeVarint(out, packet.length);
        out.write(packet);
        out.flush();
    }
    public static byte[] receive(InputStream in) throws IOException {
        long len = readVarint(in);
        if (len < 0 || len > 1_048_576) throw new IOException("Invalid frame length " + len);
        byte[] result = new byte[(int) len];
        int off = 0;
        while (off < result.length) {
            int r = in.read(result, off, result.length - off);
            if (r < 0) throw new EOFException("Incomplete frame");
            off += r;
        }
        return result;
    }
    public static Map<Integer, Object> parse(byte[] b) throws IOException {
        HashMap<Integer, Object> out = new HashMap<>();
        InputStream in = new java.io.ByteArrayInputStream(b);
        while (in.available() > 0) {
            long tag = readVarint(in);
            int field = (int) (tag >>> 3), wire = (int) (tag & 7);
            if (field <= 0) throw new IOException("Bad protobuf field");
            if (wire == 0) out.put(field, readVarint(in));
            else if (wire == 2) {
                long length = readVarint(in);
                if (length > in.available()) throw new IOException("Short protobuf payload");
                byte[] payload = new byte[(int) length];
                if (payload.length > 0) {
                    int count = in.read(payload);
                    if (count != payload.length) throw new IOException("Short protobuf payload");
                }
                out.put(field, payload);
            } else if (wire == 1 || wire == 5) {
                int n = wire == 1 ? 8 : 4;
                if (in.skip(n) != n) throw new IOException("Short protobuf fixed field");
            } else throw new IOException("Unknown protobuf wire type " + wire);
        }
        return out;
    }
    public static boolean has(Map<Integer, Object> msg, int id) { return msg.containsKey(id); }
    public static long number(Map<Integer, Object> msg, int id) {
        Object val = msg.get(id);
        return val instanceof Long ? (Long) val : 0;
    }
    public static Map<Integer, Object> sub(Map<Integer, Object> msg, int id) throws IOException {
        Object val = msg.get(id);
        if (!(val instanceof byte[])) return new HashMap<>();
        return parse((byte[]) val);
    }
}
