package com.cecbridge.remotev2;

import java.io.IOException;
import java.util.Map;
import javax.net.ssl.SSLSocket;

/** Google Polo pairing client; one socket remains open while PIN is entered. */
public final class PairingClient implements AutoCloseable {
    private final IdentityStore identity;
    private SSLSocket socket;

    public PairingClient(IdentityStore identity) { this.identity = identity; }

    private static byte[] message(int field, byte[] inner) {
        return Proto.cat(Proto.uint(1, 2), Proto.uint(2, 200), Proto.bytes(field, inner));
    }

    private Map<Integer, Object> receiveChecked() throws Exception {
        Map<Integer, Object> packet = Proto.parse(Proto.receive(socket.getInputStream()));
        long status = Proto.number(packet, 2);
        if (status != 200) throw new IOException("电视拒绝配对，错误码 " + status);
        return packet;
    }

    private void send(int field, byte[] body) throws Exception {
        Proto.send(socket.getOutputStream(), message(field, body));
    }

    public void begin(String host) throws Exception {
        close();
        socket = identity.connect(host, 6467);
        try {
            send(10, Proto.cat(Proto.str(1, "atvremote"), Proto.str(2, "CEC Remote V2")));
            boolean requestAck = false, offeredOptions = false;
            for (int tries = 0; tries < 8; tries++) {
                Map<Integer, Object> reply = receiveChecked();
                if (Proto.has(reply, 11) && !requestAck) {
                    byte[] encoding = Proto.cat(Proto.uint(1, 3), Proto.uint(2, 6));
                    send(20, Proto.cat(Proto.bytes(1, encoding), Proto.uint(3, 1)));
                    requestAck = true;
                } else if (Proto.has(reply, 20) && !offeredOptions) {
                    byte[] encoding = Proto.cat(Proto.uint(1, 3), Proto.uint(2, 6));
                    send(30, Proto.cat(Proto.bytes(1, encoding), Proto.uint(2, 1)));
                    offeredOptions = true;
                } else if (Proto.has(reply, 31) && offeredOptions) {
                    return; // TV now displays the six-character PIN.
                } else throw new IOException("配对握手顺序不匹配");
            }
            throw new IOException("电视未完成配对握手");
        } catch (Exception ex) { close(); throw ex; }
    }

    /** Returns TV cert fingerprint. Caller persists only after a valid pairing ack. */
    public String finish(String pin) throws Exception {
        if (socket == null || socket.isClosed()) throw new IOException("请先点击开始配对");
        try {
            byte[] code = IdentityStore.pairingSecret(
                    identity.clientCertificate(), IdentityStore.serverCert(socket), pin.trim());
            send(40, Proto.bytes(1, code));
            Map<Integer, Object> reply = receiveChecked();
            if (!Proto.has(reply, 41)) throw new IOException("未收到电视配对成功确认");
            return IdentityStore.fingerprint(IdentityStore.serverCert(socket));
        } finally { close(); }
    }

    @Override public void close() {
        if (socket != null) {
            try { socket.close(); } catch (Exception ignored) { }
            socket = null;
        }
    }
}
