package com.cecbridge.remotev2;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLSocket;

/** An authenticated Remote v2 session with ping replies, feature negotiation and state. */
public final class RemoteSession implements AutoCloseable {
    public interface Listener {
        void status(String status);
        void powerState(Boolean isOn);
        default void volumeState(int level, int max, boolean muted) { }
    }

    private final IdentityStore identity;
    private final Listener listener;
    private final Object sendLock = new Object();
    private volatile SSLSocket socket;
    private volatile Boolean isOn;
    private volatile boolean ready;
    private volatile int featureMask = 611; // PING, KEY, POWER, VOLUME, APP_LINK
    private CountDownLatch readyLatch = new CountDownLatch(1);

    public RemoteSession(IdentityStore identity, Listener listener) {
        this.identity = identity;
        this.listener = listener;
    }

    public Boolean isOn() { return isOn; }
    public boolean isReady() { return ready && socket != null && !socket.isClosed(); }

    public void connect(String host, String expectedFingerprint) throws Exception {
        close();
        SSLSocket s = identity.connect(host, 6466);
        try {
            String actual = IdentityStore.fingerprint(IdentityStore.serverCert(s));
            if (!actual.equalsIgnoreCase(expectedFingerprint))
                throw new SecurityException("设备证书变化，已阻止发送；请重新配对");
            s.setSoTimeout(0); // remote service sends periodic keepalives
            socket = s;
            readyLatch = new CountDownLatch(1);
            isOn = null;
            Thread reader = new Thread(() -> readLoop(s), "cec-remote-reader");
            reader.setDaemon(true);
            reader.start();
            if (!readyLatch.await(6, TimeUnit.SECONDS) || !isReady()) {
                throw new IOException("Google TV 未完成遥控协议初始化");
            }
        } catch (Exception ex) {
            try { s.close(); } catch (Exception ignored) { }
            if (socket == s) socket = null;
            throw ex;
        }
    }

    private void readLoop(SSLSocket s) {
        try {
            while (!s.isClosed()) {
                Map<Integer, Object> packet = Proto.parse(Proto.receive(s.getInputStream()));
                if (Proto.has(packet, 1)) { // Server's RemoteConfigure
                    long supported = Proto.number(Proto.sub(packet, 1), 1);
                    featureMask = (int) supported & 611;
                    byte[] info = Proto.cat(Proto.uint(3, 1), Proto.str(4, "1"),
                            Proto.str(5, "com.cecbridge.remotev2"), Proto.str(6, "2.0"));
                    sendPacket(Proto.bytes(1, Proto.cat(Proto.uint(1, featureMask), Proto.bytes(2, info))));
                } else if (Proto.has(packet, 2)) { // server set_active
                    sendPacket(Proto.bytes(2, Proto.uint(1, featureMask)));
                } else if (Proto.has(packet, 8)) { // server ping
                    long id = Proto.number(Proto.sub(packet, 8), 1);
                    sendPacket(Proto.bytes(9, Proto.uint(1, id)));
                } else if (Proto.has(packet, 40)) { // power status
                    isOn = Proto.number(Proto.sub(packet, 40), 1) != 0;
                    listener.powerState(isOn);
                    if (!ready) {
                        ready = true;
                        readyLatch.countDown();
                        listener.status("已连接 Google TV · 等待按键");
                    }
                } else if (Proto.has(packet, 50)) { // RemoteSetVolumeLevel from TV
                    Map<Integer, Object> v = Proto.sub(packet, 50);
                    listener.volumeState((int) Proto.number(v, 7),
                            (int) Proto.number(v, 6), Proto.number(v, 8) != 0);
                } else if (Proto.has(packet, 3)) {
                    listener.status("电视报告遥控协议错误，请重新配对");
                }
                // Some firmware responds with set_active rather than remote_start.
                if (!ready && (Proto.has(packet, 2) || Proto.has(packet, 1))) {
                    ready = true;
                    readyLatch.countDown();
                    listener.status("已连接 Google TV · 电源状态检测中");
                }
            }
        } catch (Exception ex) {
            if (socket == s) listener.status("连接中断，可点击连接重试：" + ex.getMessage());
        } finally {
            if (socket == s) {
                ready = false;
                socket = null;
                isOn = null;
                listener.powerState(null);
            }
            readyLatch.countDown();
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    private void sendPacket(byte[] body) throws IOException {
        synchronized (sendLock) {
            SSLSocket s = socket;
            if (s == null || s.isClosed()) throw new IOException("Google TV 未连接");
            Proto.send(s.getOutputStream(), body);
        }
    }

    private void sendKeyDirection(int androidKeyCode, int direction) throws IOException {
        if (!isReady()) throw new IOException("Google TV 未完成连接");
        // Android RemoteKeyInject: START_LONG=1, END_LONG=2, SHORT=3.
        sendPacket(Proto.bytes(10, Proto.cat(Proto.uint(1, androidKeyCode), Proto.uint(2, direction))));
    }

    public void sendKey(int androidKeyCode) throws IOException {
        sendKeyDirection(androidKeyCode, 3);
    }

    /**
     * Android TV Remote v2 APP_LINK_LAUNCH_REQUEST (field 90).
     * The remote service cannot enumerate installed applications. For package names,
     * use the Play Store's launch entry point; it may show the store on some devices.
     */
    public void launchApp(String target) throws IOException {
        if (!isReady()) throw new IOException("Google TV 尚未连接");
        if ((featureMask & 512) == 0) throw new IOException("这台 Google TV 未提供 App Link 启动能力");
        if (target == null || target.trim().isEmpty()) throw new IOException("未填写启动链接");
        target = target.trim();
        final String url;
        final String packageHint;
        final boolean storeFallback;
        if (target.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+")) {
            url = "https://play.google.com/apps/launch?id=" + target;
            packageHint = "com.android.vending";
            storeFallback = true;
        } else {
            url = target;
            packageHint = null;
            storeFallback = false;
        }
        byte[] fields = Proto.str(1, url);
        if (packageHint != null) fields = Proto.cat(fields, Proto.str(2, packageHint));
        if (storeFallback) fields = Proto.cat(fields, Proto.uint(3, 1));
        sendPacket(Proto.bytes(90, fields));
    }

    /** Open a package's Play Store detail page for a manual user-confirmed Open action. */
    public void openAppStorePage(String packageName) throws IOException {
        if (!isReady()) throw new IOException("Google TV 尚未连接");
        if ((featureMask & 512) == 0) throw new IOException("Google TV 不支持 App Link 启动请求");
        if (packageName == null || !packageName.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+"))
            throw new IOException("请先为电视 App 填写包名，而不是 URL");
        String url = "https://play.google.com/store/apps/details?id=" + packageName;
        byte[] fields = Proto.cat(Proto.str(1, url), Proto.str(2, "com.android.vending"));
        sendPacket(Proto.bytes(90, fields));
    }

    /** Optional protocol diagnostic; a long press is NOT a direct CEC command. */
    public void sendKeyLongPress(int androidKeyCode, int durationMillis) throws IOException {
        sendKeyDirection(androidKeyCode, 1);
        try {
            Thread.sleep(Math.max(150, Math.min(durationMillis, 600)));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            sendKeyDirection(androidKeyCode, 2);
        }
    }

    @Override public void close() {
        SSLSocket s = socket;
        ready = false;
        isOn = null;
        socket = null;
        readyLatch.countDown();
        if (s != null) try { s.close(); } catch (Exception ignored) { }
    }
}
