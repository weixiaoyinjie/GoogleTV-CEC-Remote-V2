package com.cecbridge.remotev2;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * One-shot activity started from a pinned launcher shortcut.
 * Never displays the full remote UI; pairs once in MainActivity and reuses that TLS identity.
 * Every outcome is a SEND/CONNECTION outcome, not a claim that the television changed state.
 */
public final class QuickActionActivity extends Activity {
    public static final String ACTION_SLEEP = "com.cecbridge.remotev2.action.TV_SLEEP";
    public static final String ACTION_WAKE = "com.cecbridge.remotev2.action.TV_WAKE";
    public static final String ACTION_TOGGLE = "com.cecbridge.remotev2.action.TV_POWER_TOGGLE";
    private static final String PREFS = "google_tv_remote_v2";
    private static final AtomicBoolean WORKING = new AtomicBoolean(false);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        final String action = getIntent() == null ? null : getIntent().getAction();
        final int code;
        final String label;
        if (ACTION_SLEEP.equals(action)) {code = 223;label="待机";}
        else if (ACTION_WAKE.equals(action)) {code = 224;label="唤醒";}
        else if (ACTION_TOGGLE.equals(action)) {code = 26;label="切换电源";}
        else {finish();return;}

        final SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        final String host = prefs.getString("host", "").trim();
        final String fingerprint = prefs.getString("tv_fingerprint", "").trim();
        if (host.isEmpty() || fingerprint.isEmpty()) {
            toastAndFinish("请先打开 TV Remote 完成六位码配对");return;
        }
        if (!WORKING.compareAndSet(false, true)) {
            toastAndFinish("遥控指令正在发送，请稍后重试");return;
        }
        Thread worker = new Thread(() -> {
            String message;
            RemoteSession session = null;
            try {
                IdentityStore identity = new IdentityStore(getApplicationContext());
                session = new RemoteSession(identity, new RemoteSession.Listener() {
                    @Override public void status(String status) { }
                    @Override public void powerState(Boolean isOn) { }
                });
                session.connect(host, fingerprint);
                session.sendKey(code);
                // Leave TLS open briefly to allow the remote service to receive the command.
                try {Thread.sleep(250);} catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                }
                message = "已向 Google TV 发送" + label + "指令";
            } catch (Exception error) {
                String reason = error.getMessage();
                message = "Google TV " + label + "失败：" + (reason == null ? "连接异常" : reason);
            } finally {
                if (session != null) session.close();
                WORKING.set(false);
            }
            final String result = message;
            runOnUiThread(() -> toastAndFinish(result));
        }, "google-tv-shortcut-command");
        worker.start();
    }

    private void toastAndFinish(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
        finish();
    }
}
