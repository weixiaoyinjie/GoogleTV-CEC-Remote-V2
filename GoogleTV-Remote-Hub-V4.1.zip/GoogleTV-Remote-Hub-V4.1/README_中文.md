# Google TV Remote Hub V4.1（桌面快捷开关与 Google Play 辅助）

这是基于 Google TV Remote Hub V4 的增强版：**完全移除了 HDMI-CEC、S61B 音量和投影机控制界面**，只使用 Android TV Remote Protocol V2，通过 Wi-Fi 连接 Google TV。

## 新增：手机桌面一键操作

1. 在 App「连接与首次配对」中完成 Google TV 六位码配对，保存电视 IP。
2. 在首页「手机桌面快捷方式」点击「＋ 桌面关机」，在 Android 弹窗里确认添加。
3. 手机主屏幕将多出独立图标「关闭 Google TV」。直接点击就发送 `KEYCODE_SLEEP (223)`；不会打开完整遥控页面，只显示发送成功/失败 Toast。也可以添加「唤醒 Google TV」(224) 或「Google TV 开关」(26) 图标。
4. 桌面快捷方式依赖原 App 的配对证书，且手机与 Google TV 需要网络互通；卸载 App 后旧快捷方式无法工作。待机后网络断开则无法唤醒。
5. Android 使用系统 `ShortcutManager.requestPinShortcut()`，不同手机桌面可能需要用户确认，或不支持自动置顶。

## 新增：Google Play 启动备用方式

- App 按钮继续优先通过 Remote V2 的 App Link（field 90）使用 `https://play.google.com/apps/launch?id=<包名>` 请求电视 Play 商店直接打开已安装应用。
- 电视若未直接进入 App，可在「Google Play 备用启动方式」点击「打开电视 Play 商店详情」，选择 Kodi、Qobuz 或其他以包名配置的应用；电视进入详情页后，用方向键选中「打开」，再点「确定 / 打开」。
- **不自动执行盲目确认**：Play 商店界面和焦点随设备改变，自动按确定可能误触「安装／购买」。此备用方式并不保证所有 Google TV 兼容。

## 功能

- Google TV：唤醒（224）、待机（223）、电源切换（26）。待机不是硬断电；休眠后网络断开时可能无法唤醒。
- 首次六位代码配对（6467），TLS 安全会话（6466），持久化本机证书；保留原工程的包名与 SharedPreferences 名称，便于兼容更新。
- 默认快捷按钮：Kodi（org.xbmc.kodi），Qobuz（com.qobuz.music）；**长按按钮可以编辑或删除**；「＋ 添加电视 App」可添加其他电视应用。
- 应用启动：Google TV Remote V2 协议字段 90 APP_LINK_LAUNCH_REQUEST。对包名使用 `https://play.google.com/apps/launch?id=包名`，指定 Play 商店处理。部分设备会打开商店而不是启动应用，或不支持这个入口；可改为应用已注册的深度链接。发送成功不保证电视实际打开了应用。
- 播放暂停（85）、上一项（88）、下一项（87）、快退（89）、快进（90）、停止（86）、方向键、确定、返回、主页、菜单。
- App 名称和启动参数保存在本机 SharedPreferences，不会上传到服务器。

## 限制说明

1. **无电视端辅助 App 或 ADB** 时，协议无法自动罗列电视已经安装的应用，因此只能手动添加包名或可处理的 URL。
2. 快进快退、上一视频/下一视频的效果受各播放软件的遥控按键映射影响。并非所有播放器都支持。左右方向键是备用测试，不代表精确的 ±10 秒跳转。
3. 需要在 Google TV 上已安装 Kodi / Qobuz / 其他目标应用。Qobuz TV 包名为 com.qobuz.music。
4. 手机和 TV 需在同一局域网。Google TV 待机时远程唤醒依赖系统是否保持网络唤醒。
5. APK 可能因 Android debug 签名变化不能直接覆盖 V3；卸载旧版将丢失配对凭据，需重新配对。要长期免重新配对，需要固定的私有签名密钥。
6. 此版本不实现显示设备 CEC 电源、S61B 音量功能。

## 建议测试顺序

1. 安装后连接 IP；如果已有兼容的 V3 记录可尝试自动连接，否则用六位配对码配对。
2. 测试 Google TV 唤醒/待机；确认原本有效的功能仍然有效。
3. 测试 Kodi/Qobuz，一旦进入 Play 商店或没响应，长按按钮更换启动链接。
4. 在 Kodi 或播放器里测试播放暂停、上一个/下一个、快进/快退；必要时测试左右方向键。

## GitHub Actions

在仓库根目录上传 `GoogleTV-Remote-Hub-V4.1.zip`，然后把 `build-apk-v4-1.yml` 内容保存到 `.github/workflows/build-apk.yml`。它会自动解压 V4.1 ZIP 并使用 Gradle 8.9、JDK 17、Android API 35 编译。成功后从 Artifacts 下载 `GoogleTV-Remote-Hub-V4.1-APK`。

源码版本需在 GitHub Actions 实际编译和 Google TV 实机运行之后才能确认最终兼容性。
